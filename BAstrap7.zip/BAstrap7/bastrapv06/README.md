<h1>BAstrap</h1>

<p>La herramienta que permite unificar la interfaz de los sitios web del Gobierno de la Ciudad de Buenos Aires. Usa HTML, CSS, y JS basado en Bootstrap.</p>

<p><a href="http://gcba.github.io/BAstrap/" target="_blank">http://gcba.github.io/BAstrap/</a></p>
